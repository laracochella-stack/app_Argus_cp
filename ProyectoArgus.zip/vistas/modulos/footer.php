<?php
/**
 * Pie de página
 */
?>
<footer class="main-footer text-center">
  <small>&copy; <?php echo date('Y'); ?> Contratos Grupo Argus</small>
</footer>