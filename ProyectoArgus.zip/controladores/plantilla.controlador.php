<?php
class ControladorPlantilla {
    /**
     * Renderiza la plantilla principal.
     */
    public function ctrPlantilla() {
        include 'vistas/plantilla.php';
    }
}